writetimetable(eightwashers,eightwashers)
